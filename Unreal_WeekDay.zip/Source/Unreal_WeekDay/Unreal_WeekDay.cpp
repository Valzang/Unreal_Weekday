// Copyright Epic Games, Inc. All Rights Reserved.

#include "Unreal_WeekDay.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Unreal_WeekDay, "Unreal_WeekDay" );
